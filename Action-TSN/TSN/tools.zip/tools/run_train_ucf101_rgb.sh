#!/usr/bin bash

python3.6 tools/train.py configs/recognition/tsn/tsn_r50_1x1x3_80e_ucf101_rgb.py \
        --work-dir work_dirs/tsn_r50_1x1x3_80e_ucf101_rgb \
        --validate --seed 0 --deterministic \
        --gpu-ids 2