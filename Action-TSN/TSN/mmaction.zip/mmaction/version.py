# GENERATED VERSION FILE
# TIME: Fri Jul 17 16:39:48 2020
__version__ = '0.1.0+3aefca8'
short_version = '0.1.0'
version_info = (0, 1, 0)
