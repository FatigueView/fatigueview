#! /usr/bin/bash env

cd ../
python3.6 build_rawframes.py ../../data/ucf101/videos/ ../../data/ucf101/rawframes/ --task rgb --level 1 --ext avi --use-opencv
echo "Genearte raw frames (RGB only)"

cd ucf101/
