import os.path as osp
import os
import random

video_gt_file = '/home/users/yunhui.zhang/yunhui.zhang/data/emotion_frame_gt.txt'


def get_person_id(video_name):
    info = video_name.split('_')

    try:
        t = int(info[0])
        return str(int(t))
    except:
        try:
            t = int(info[1])
            return str(int(t))
        except:
            return video_name

def split_train_val(save_root, train_ratio=0.7, val_ratio=0.1, test_ratio=0.2):
    random.seed = 2020

    video_info_lst = []
    for line in open(video_gt_file, 'r').readlines():
        info = line.strip('\n').split(' ')
        video_info_lst.append(info)

    video_id_dict = {}
    for info in video_info_lst:
        video_name = info[0]
        person_id = get_person_id(video_name)

        if person_id not in video_id_dict:
            video_id_dict[person_id] = []
        video_id_dict[person_id].append(info)

    print(len(video_id_dict))

    video_person_lst = []
    for person_id in video_id_dict.keys():
        video_person_lst.append(video_id_dict[person_id])

    random.shuffle(video_person_lst)
    train_lst, val_lst, test_lst = [], [], []
    for i, info in enumerate(video_person_lst):
        if i < int(len(video_person_lst)*train_ratio):
            train_lst.extend(info)
        elif i < int(len(video_person_lst)*(train_ratio+val_ratio)):
            val_lst.extend(info)
        else:
            test_lst.extend(info)
    print("split train:{}, val:{}, test:{}".format(len(train_lst), len(val_lst), len(test_lst)))
    train_txt, val_txt, test_txt = open(os.path.join(save_root, 'train_lst.txt'), 'w'), open(os.path.join(save_root, 'val_lst.txt'), 'w'), open(os.path.join(save_root, 'test_lst.txt'), 'w')
    for info in train_lst:
        train_txt.write("{} {} {}\n".format(info[0], int(info[1])-1, info[2]))
    for info in val_lst:
        val_txt.write("{} {} {}\n".format(info[0], int(info[1])-1, info[2]))
    for info in test_lst:
        test_txt.write("{} {} {}\n".format(info[0], int(info[1])-1, info[2]))




if __name__ == "__main__":
    save_root = 'data/emotion'
    split_train_val(save_root)
