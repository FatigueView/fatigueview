#! /usr/bin/bash env

cd ../../../

PYTHONPATH=. python3.6 tools/data/build_file_list.py ucf101 data/ucf101/rawframes/ --level 1 --format rawframes --shuffle
echo "Filelist for rawframes generated."

cd tools/data/ucf101/
