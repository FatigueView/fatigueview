import os
from tqdm import tqdm

img_dir = '/home/users/yunhui.zhang/yunhui.zhang/data/emtion_mf'
dst_dir = '../../../data/emotion/video_train'

def make_sym(img_root):
    for r, _, fs in tqdm(os.walk(img_dir)):
        fs = sorted(fs)

        for i, f in enumerate(fs):
            dir_name = r.split('/')[-1]
            src = os.path.join(r, f)
            dst = os.path.join(dst_dir, dir_name, 'img_%05d.png'%i)
            # print(src, dst)
            dst_dir_file = os.path.dirname(dst)
            # print(dst_dir_file)
            if not os.path.exists(dst_dir_file):
                os.makedirs(dst_dir_file)
            os.system('ln -s {} {}'.format(src, dst))

make_sym(img_dir)