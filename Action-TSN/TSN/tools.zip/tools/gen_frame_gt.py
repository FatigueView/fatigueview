import os

CLASS_NAMES = ['Angry', 'Happy', 'Neutral', 'Other', 'Sad']
def gen_gt(video_root, lab_path, save_gt_file):
    label_dict = {}
    video_dirs = os.listdir(video_root)

    lines = open(lab_path, 'r').readlines()
    for line in lines:
        video_name, label = line.strip('\n').split(' ')
        if video_name not in video_dirs:
            print(video_name, " not exist")
            continue
        if label in CLASS_NAMES:
            label_dict[video_name] = CLASS_NAMES.index(label)
        else:
            label_dict[video_name] = 3

    save_file = open(save_gt_file, 'w')
    for video in label_dict.keys():
        label = label_dict[video]
        frame_len = len(os.listdir(os.path.join(video_root, video)))
        save_file.write("{} {} {}\n".format(video, frame_len, label))


if __name__ == '__main__':
    video_root = 'data/emotion/video_train'
    label_path = '/home/users/yunhui.zhang/yunhui.zhang/data/emtion_multi_frame.lab'
    save_gt_file = '/home/users/yunhui.zhang/yunhui.zhang/data/emotion_frame_gt.txt'

    gen_gt(video_root, label_path, save_gt_file)




