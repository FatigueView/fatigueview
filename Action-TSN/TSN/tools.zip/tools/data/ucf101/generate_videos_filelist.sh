#! /usr/bin/bash env

cd ../../../

PYTHONPATH=. python3.6 tools/data/build_file_list.py ucf101 data/ucf101/videos/ --level 1 --format videos --shuffle
echo "Filelist for videos generated."

cd tools/data/ucf101/
