# -*- coding: UTF-8 -*-
'''=================================================
@Author ：zhenyu.yang
@Date   ：2020/11/11 2:30 PM
=================================================='''

import os
import shutil
from multiprocessing import Pool

def getFiles(path, suffix):
    return [os.path.join(root, file) for root, dirs, files in os.walk(path)
            for file in files if file.endswith(suffix)]

def refine_one_dir(video_dir):
    img_list = os.listdir(video_dir)
    img_list.sort()

    for i,img in enumerate(img_list):
        new_name = '{}.jpg'.format(str(i).zfill(8))
        shutil.move(os.path.join(video_dir,img),os.path.join(video_dir,new_name))



if __name__ =='__main__':
    src_dir = '/data-sdc/yunhui.zhang/data/train/'
    src_dir = '/data-sdb/yunhui.zhang/test'


    video_list =  getFiles(src_dir,'.jpg')

    video_list = ['/'+os.path.join(*v.split(os.sep)[:-1]) for v in video_list]
    video_list = list(set(video_list))

    pool = Pool(32)
    pool.map(refine_one_dir,video_list)
    pool.close()
    pool.join()
