import os
import os.path as osj
from tqdm import tqdm

def get_videos(video_root):
    return sorted([osj.join(video_root, video) for video in os.listdir(video_root)])


def main(video_root, save_root):
    video_names = get_videos(video_root)

    for i, video in tqdm(enumerate(video_names)):
        image_files = sorted([osj.join(video, i) for i in os.listdir(video)])

        for i, image in enumerate(image_files):
            save_path = osj.join(save_root, video.split('/')[-1], 'img_%05d.png'%(i))
            save_dir = osj.join(save_root, video.split('/')[-1])

            if not os.path.exists(save_dir):
                os.makedirs(save_dir)

            os.symlink(image, save_path)

if __name__ == '__main__':
    video_root = '/home/users/yunhui.zhang/yunhui.zhang/data/emtion_mf'
    save_root = 'data/emotion/video_train'

    main(video_root, save_root)
