from .conv2plus1d import Conv2plus1d

__all__ = ['Conv2plus1d']
