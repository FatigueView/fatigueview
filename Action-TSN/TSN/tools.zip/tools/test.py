import argparse
import os
import numpy as np
import sys
sys.path.append('..')
sys.path.append('.')
sys.path.append('./mmaction')

import mmcv
import torch
from mmcv.parallel import MMDataParallel, MMDistributedDataParallel
from mmcv.runner import get_dist_info, init_dist, load_checkpoint

from mmaction.apis import multi_gpu_test, single_gpu_test
from mmaction.datasets import build_dataloader, build_dataset
from mmaction.models import build_model


def parse_args():
    parser = argparse.ArgumentParser(
        description='MMAction2 test (and eval) a model')
    parser.add_argument('config', default='configs/recognition/tsn/tsn_r50_dense_1x1x8_100e_kinetics400_rgb.py', help='test config file path')
    parser.add_argument('checkpoint', default='work_dirs/tsn_r50_dense_1x1x8_100e_kinetics400_rgb/latest.pth', help='checkpoint file')
    parser.add_argument(
        '--gpus', default=1, type=int, help='GPU number used for testing')
    parser.add_argument(
        '--out', default=None, help='output result file in pickle format')
    parser.add_argument(
        '--eval',
        type=str,
        nargs='+',
        help='evaluation metrics, which depends on the dataset, e.g.,'
        ' "top_k_accuracy", "mean_class_accuracy" for video dataset')
    parser.add_argument(
        '--gpu-collect',
        action='store_true',
        help='whether to use gpu to collect results')
    parser.add_argument(
        '--tmpdir',
        help='tmp directory used for collecting results from multiple '
        'workers, available when gpu-collect is not specified')
    parser.add_argument('--options', nargs='+', help='custom options')
    parser.add_argument(
        '--average-clips',
        choices=['score', 'prob'],
        default='score',
        help='average type when averaging test clips')
    parser.add_argument(
        '--launcher',
        choices=['none', 'pytorch', 'slurm', 'mpi'],
        default='none',
        help='job launcher')
    parser.add_argument('--local_rank', type=int, default=0)
    args = parser.parse_args()
    if 'LOCAL_RANK' not in os.environ:
        os.environ['LOCAL_RANK'] = str(args.local_rank)
    return args


def merge_configs(cfg1, cfg2):
    # Merge cfg2 into cfg1
    # Overwrite cfg1 if repeated, ignore if value is None.
    cfg1 = {} if cfg1 is None else cfg1.copy()
    cfg2 = {} if cfg2 is None else cfg2
    for k, v in cfg2.items():
        if v:
            cfg1[k] = v
    return cfg1


def softmax(x):
    z = np.exp(x)/sum(np.exp(x))
    return z


def eval_pr(outputs, dataset):
    gt_labels = [ann['label'] for ann in dataset.video_infos]

    labels = np.array(gt_labels)[:, np.newaxis]


    for thresh in np.arange(0, 1, 0.02):
        tp, fp, tn, fn = 0, 0, 0, 0
        for i, (gt, pred) in enumerate(zip(labels, outputs)):
            # print(gt, pred)
            gt = 1 if gt[0] == 1 else 0 #gt[0] == 1
            prob = softmax(pred)
            #print(prob)

            if prob[1] > thresh:
                pred = 1
            else:
                pred = 0
            #print(gt, pred)
            if pred == gt and gt == 1:
                tp += 1
            elif pred == gt and gt == 0:
                tn += 1
            elif pred != gt and gt == 1:
                fn += 1
            else:
                fp += 1

        print("thresh: {} : precision: {}, recall:{}".format(thresh, 1.*tp/(tp+fp), 1.*tp/(tp+fn)))

def eval_acc(outputs, dataset):
    gt_labels = [ann['label'] for ann in dataset.video_infos]

    labels = np.array(gt_labels)[:, np.newaxis]

    num_hit = 0
    count = 0
    for i, (gt, pred) in enumerate(zip(labels, outputs)):
        gt = gt[0]
        if gt == 4:
            gt = 0

        prob = softmax(pred)

        prediction = np.argmax(prob)
        if prediction == 4:
            prediction = 0
        if prediction == gt:
            num_hit += 1
        count += 1

    acc = 1. * num_hit / count
    print("acc: %s"%acc)



def calc_pr_multi_class(score_lst, dataset): #, image_lst, save_error_file, mode='max'):
    _CLASS_NAMES = ['Angry', 'Happy', 'Neutral', 'Other', 'Sad']
    num_preds = np.zeros(len(_CLASS_NAMES))
    num_tps = np.zeros(len(_CLASS_NAMES))
    num_gts = np.zeros(len(_CLASS_NAMES))

    gt_labels = [ann['label'] for ann in dataset.video_infos]

    labels = np.array(gt_labels)[:, np.newaxis]
    # error_files = [open('error_{}_{}.txt'.format(_CLASS_NAMES[pred], _CLASS_NAMES[label])]
    for i, (score, label) in enumerate(zip(score_lst, labels)):
        pred = np.argmax(score)
        if pred == 3:
            pred = 2
        # if pred == 4:
        #     pred = 0
        # if label == 4:
        #     label = 0
        num_preds[pred] += 1
        num_gts[label] += 1



        if pred == label:
            num_tps[pred] += 1
        else:
            pass
            # save_dir = 'error/{}_{}'.format(_CLASS_NAMES[label], _CLASS_NAMES[pred])
            # if not os.path.exists(save_dir):
            #     os.makedirs(save_dir)
            # shutil.copy(image_lst[i], save_dir + '/' + '{}'.format(image_lst[i].split('/')[-1]))

    for i, (num_pred, num_tp, num_gt) in enumerate(zip(num_preds, num_tps, num_gts)):
        print("{}: precision: {}, recall : {}".format( _CLASS_NAMES[i], 1. * num_tp / num_pred, 1. * num_tp / num_gt))

def main():
    args = parse_args()

    cfg = mmcv.Config.fromfile(args.config)

    # Load output_config from cfg
    output_config = cfg.get('output_config', {})
    # Overwrite output_config from args.out
    output_config = merge_configs(output_config, dict(out=args.out))

    # Load eval_config from cfg
    eval_config = cfg.get('eval_config', {})
    # Overwrite eval_config from args.eval
    eval_config = merge_configs(eval_config, dict(metrics=args.eval))
    # Add options from args.option
    eval_config = merge_configs(eval_config, args.options)

    assert output_config or eval_config, \
        ('Please specify at least one operation (save or eval the '
         'results) with the argument "--out" or "--eval"')

    # set cudnn benchmark
    if cfg.get('cudnn_benchmark', False):
        torch.backends.cudnn.benchmark = True
    cfg.data.test.test_mode = True

    if cfg.test_cfg is None:
        cfg.test_cfg = dict(average_clips=args.average_clips)
    else:
        cfg.test_cfg.average_clips = args.average_clips

    # init distributed env first, since logger depends on the dist info.
    if args.launcher == 'none':
        distributed = False
    else:
        distributed = True
        init_dist(args.launcher, **cfg.dist_params)

    # build the dataloader
    dataset = build_dataset(cfg.data.test, dict(test_mode=True))
    data_loader = build_dataloader(
        dataset,
        videos_per_gpu=1,
        workers_per_gpu=cfg.data.workers_per_gpu,
        dist=distributed,
        shuffle=False)

    # build the model and load checkpoint
    model = build_model(cfg.model, train_cfg=None, test_cfg=cfg.test_cfg)
    load_checkpoint(model, args.checkpoint, map_location='cpu')

    # print(model.features)
    # for data in data_loader:
        # from torchviz import make_dot, make_dot_from_trace
        # x = torch.autograd.Variable(data)
        # with torch.no_grad():
        #     y = model(return_loss=False, **data)

        # make_dot(y, params=dict(list(model.named_parameters())))
       # print(data['imgs'].shape, data['label'])

    if not distributed:
        model = MMDataParallel(model, device_ids=[0])
        outputs = single_gpu_test(model, data_loader)
    else:
        model = MMDistributedDataParallel(
            model.cuda(),
            device_ids=[torch.cuda.current_device()],
            broadcast_buffers=False)
        outputs = multi_gpu_test(model, data_loader, args.tmpdir,
                                 args.gpu_collect)

    eval_pr(outputs, dataset)
    # calc_pr_multi_class(outputs, dataset)
    eval_acc(outputs, dataset)
    rank, _ = get_dist_info()
    if rank == 0:
        if output_config:
            out = output_config['out']
            print('\nwriting results to {}'.format(out))
            dataset.dump_results(outputs, **output_config)
        if eval_config:
            #print(outputs)
            eval_res = dataset.evaluate(outputs, **eval_config)
            for name, val in eval_res.items():
                print('{name}: {val:.04f}')


if __name__ == '__main__':
    main()
